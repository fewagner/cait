from abc import ABC, abstractmethod
from inspect import signature


class FncBaseClass(ABC):   
    """
    Abstract class that represents a function which is meant to be applied to event voltage traces. The configuration of the function (i.e. setting its non-event input values) is done upon initialization. As a convention, function inputs will be saved in corresponding class attributes prepended with an underscore (e.g. for a function receiving a parameter `param`, a corresponding `self._param` will be defined in the `__init__`.)

    This class defines two necessary methods: `__call__` which takes one argument (the event voltage trace; can be multiple channels, depending on the function implementation) and returns the result. Multiple results are returned as tuples (e.g. `return result1, result2`) and if one result is a list/vector, it is encouraged to return a `numpy.ndarray`.
    The `preview` method is called when the function is used in combination with the :class:`Preview` class and (if implemented) is expected to return a dictionary of the form specified in :class:`Preview`. 
    """
    def __repr__(self):
        params = signature(self.__init__).parameters.keys()
        p = ", ".join([f"{k}={getattr(self, '_'+k)}" 
                       for k in params if hasattr(self, '_'+k)])
        return f"{self.__class__.__name__}({p})"
    
    @abstractmethod
    def __call__(self, event):
        ...

    @property
    @abstractmethod
    def batch_support(self):
        """
        Returns 'trivial' if function can process all given event traces at a time in an uncorrelated manner, i.e. different channels are treated equally.
        Returns 'full' if batches (possibly with multiple channels, too) can be processed at once.
        Returns 'none' if batches are not supported.
        """
        ...
    
    def preview(self, event) -> dict:
        raise NotImplementedError(f"{self.__class__.__name__} does not support preview.")
        
class FitFncBaseClass(FncBaseClass):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    @abstractmethod
    def model(self, x, *pars):
        ...

class ScalarFncBaseclass(FncBaseClass, ABC):
    """Abstract class that forces naming of output variables and their dtypes."""
    _outputs = []
    @classmethod
    def names(cls):
        return [x[0] for x in cls._outputs]

    @classmethod
    def dtypes(cls):
        return [x[1] for x in cls._outputs]