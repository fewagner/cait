# ----------------------------------------------------------
# IMPORTS
# ----------------------------------------------------------

# -----------------------------------------------------------
# CLASS
# -----------------------------------------------------------

class StreamInterface:

    def __init__(self, run, module, channels):
        pass
        # ringbuffer struct with join and get method

    # function to access the BIN files

    # function to access the CSMPL files

    # plot a time interval of the stream

    # z score trigger

    # threshold trigger with filter